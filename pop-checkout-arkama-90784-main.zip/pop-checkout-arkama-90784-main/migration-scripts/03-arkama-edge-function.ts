// Copie este arquivo para funções do seu Supabase como `supabase/functions/arkama-integration/index.ts`
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const arkanaApiKey = Deno.env.get('ARKAMA_API_KEY');
    if (!arkanaApiKey) {
      throw new Error('ARKAMA_API_KEY não configurada');
    }

    const { action, data } = await req.json();
    const ARKAMA_API_URL = 'https://app.arkama.com.br/api/v1';

    let response: Response;
    switch (action) {
      case 'create_payment':
        response = await fetch(`${ARKAMA_API_URL}/orders`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${arkanaApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(data),
        });
        break;
      case 'check_payment':
        response = await fetch(`${ARKAMA_API_URL}/orders/${data.paymentId}`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${arkanaApiKey}`,
            'Content-Type': 'application/json',
          },
        });
        break;
      default:
        throw new Error(`Ação não suportada: ${action}`);
    }

    const contentType = response.headers.get('content-type') || '';
    let responseBody: any;
    try {
      if (contentType.toLowerCase().includes('application/json')) {
        responseBody = await response.json();
      } else {
        const text = await response.text();
        responseBody = { raw: text };
      }
    } catch (_) {
      const text = await response.text().catch(() => '');
      responseBody = { raw: text };
    }

    if (!response.ok) {
      return new Response(
        JSON.stringify({ error: 'Arkama API error', status: response.status, body: responseBody }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: response.status }
      );
    }

    return new Response(JSON.stringify(responseBody), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: response.status,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Erro desconhecido';
    return new Response(JSON.stringify({ error: message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});

// No seu supabase/config.toml adicione:
// [functions.arkama-integration]
// verify_jwt = false
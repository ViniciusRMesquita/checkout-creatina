-- ============================================
-- SQLs para exportar dados do Lovable Cloud
-- Rode cada SELECT e baixe o CSV resultante
-- ============================================

-- Produtos
SELECT id,title,description,price,image_url,is_active,created_at,updated_at
FROM public.products ORDER BY created_at;

-- Cupons
SELECT id,code,description,discount_type,discount_value,is_active,starts_at,ends_at,created_at,updated_at
FROM public.coupons ORDER BY created_at;

-- Pedidos
SELECT id,order_number,customer_name,customer_email,customer_cpf,customer_phone,
       delivery_zipcode,delivery_address,delivery_number,delivery_complement,
       delivery_neighborhood,delivery_city,delivery_state,
       payment_method,payment_status,subtotal,shipping,total,
       pix_qr_code,tracking_code,created_at,updated_at
FROM public.orders ORDER BY created_at;
# 🚀 Guia Completo de Migração para Supabase Externo

Este guia vai te ajudar a migrar do Lovable Cloud para o seu próprio projeto Supabase.

---

## 📋 Pré-requisitos

- [ ] Conta no Supabase (https://supabase.com)
- [ ] Acesso ao Backend do Lovable Cloud para exportar dados

---

## 🎯 Passo 1: Criar Projeto no Supabase

1. Acesse https://supabase.com
2. Clique em **"New Project"**
3. Escolha um nome (ex: `meu-ecommerce`)
4. Defina uma senha forte para o banco
5. Escolha a região mais próxima (ex: `South America (São Paulo)`)
6. Aguarde ~2 minutos para o projeto ser provisionado

### Anote as credenciais:

Vá em **Project Settings** → **API**:
- **URL**: `https://xxxxx.supabase.co`
- **anon/public key**: `eyJhbG...`
- **service_role key**: `eyJhbG...` (mantenha em segredo!)

---

## 🗄️ Passo 2: Criar Estrutura do Banco

1. No seu projeto Supabase, vá em **SQL Editor**
2. Clique em **"New Query"**
3. Copie TODO o conteúdo do arquivo `01-create-tables.sql`
4. Cole no editor e clique em **"Run"**
5. Aguarde a confirmação: ✅ Success

**O que isso cria:**
- ✅ Tabelas: `products`, `coupons`, `orders`
- ✅ Row Level Security (RLS) com políticas seguras
- ✅ Triggers de `updated_at`
- ✅ Configuração de Realtime para `orders`

---

## 📤 Passo 3: Exportar Dados do Lovable Cloud

### 3.1 Abrir Backend do Lovable Cloud

Clique aqui para abrir:
```
<lov-actions>
  <lov-open-backend>Abrir Backend</lov-open-backend>
</lov-actions>
```

### 3.2 Exportar Produtos

1. Vá na tabela **`products`**
2. Use o SQL do arquivo `02-export-data.sql` (seção "Produtos")
3. Clique em "Download CSV"
4. Salve como `products.csv`

### 3.3 Exportar Cupons

1. Vá na tabela **`coupons`**
2. Use o SQL do arquivo `02-export-data.sql` (seção "Cupons")
3. Clique em "Download CSV"
4. Salve como `coupons.csv`

### 3.4 Exportar Pedidos

1. Vá na tabela **`orders`**
2. Use o SQL do arquivo `02-export-data.sql` (seção "Pedidos")
3. Clique em "Download CSV"
4. Salve como `orders.csv`

---

## 📥 Passo 4: Importar Dados no Supabase

### 4.1 Importar Produtos

1. No seu Supabase, vá em **Table Editor** → **products**
2. Clique em **Insert** → **Import data from CSV**
3. Selecione `products.csv`
4. Confirme que as colunas estão mapeadas corretamente
5. Clique em **Import**

### 4.2 Importar Cupons

Repita o processo para a tabela **`coupons`** com `coupons.csv`

### 4.3 Importar Pedidos

Repita o processo para a tabela **`orders`** com `orders.csv`

---

## ⚡ Passo 5: Configurar Edge Function (Arkama)

### 5.1 Instalar Supabase CLI

```bash
# macOS/Linux
brew install supabase/tap/supabase

# Windows (PowerShell)
scoop bucket add supabase https://github.com/supabase/scoop-bucket.git
scoop install supabase
```

### 5.2 Login no Supabase

```bash
supabase login
```

### 5.3 Vincular ao Projeto

```bash
supabase link --project-ref xxxxx  # substitua xxxxx pelo ref do seu projeto
```

### 5.4 Criar a Edge Function

```bash
supabase functions new arkama-integration
```

### 5.5 Copiar o Código

Copie o conteúdo de `03-arkama-edge-function.ts` para:
```
supabase/functions/arkama-integration/index.ts
```

### 5.6 Configurar Secret

```bash
supabase secrets set ARKAMA_API_KEY=sua_chave_arkama_aqui
```

### 5.7 Deploy

```bash
supabase functions deploy arkama-integration
```

### 5.8 Configurar no config.toml

Adicione ao arquivo `supabase/config.toml`:
```toml
[functions.arkama-integration]
verify_jwt = false
```

---

## 🔧 Passo 6: Atualizar Código do Projeto

### 6.1 Atualizar .env

Edite o arquivo `.env` na raiz do projeto:

```env
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=eyJhbG...  # sua anon key
VITE_SUPABASE_PROJECT_ID=xxxxx
```

### 6.2 Remover código temporário

Após atualizar o `.env`, os tipos do Supabase vão sincronizar automaticamente.

Você pode então remover as linhas `const sb = supabase as any;` dos arquivos:
- `src/components/checkout/OrderSummary.tsx`
- `src/components/checkout/StepPayment.tsx`
- `src/pages/Checkout.tsx`
- `src/pages/Products.tsx`
- `src/pages/Coupons.tsx`
- `src/pages/Dashboard.tsx`

E voltar a usar `supabase` diretamente em vez de `sb`.

---

## ✅ Passo 7: Testar

### 7.1 Testar Login Admin

1. Vá em `/auth` no seu app
2. Crie uma conta de administrador
3. Faça login

### 7.2 Testar Dashboard

1. Acesse `/dashboard`
2. Verifique se os pedidos aparecem
3. Teste adicionar código de rastreio

### 7.3 Testar Checkout

1. Acesse `/` (página inicial)
2. Teste fazer um pedido
3. Teste pagamento via PIX
4. Verifique se o pedido aparece no dashboard

### 7.4 Testar Produtos

1. Acesse `/products`
2. Crie um novo produto
3. Edite e delete produtos

### 7.5 Testar Cupons

1. Acesse `/coupons`
2. Crie um cupom de desconto
3. Teste aplicá-lo no checkout

---

## 🔐 Segurança - MUITO IMPORTANTE

### ✅ Correções Aplicadas

Este script de migração já inclui as seguintes correções de segurança:

1. **Dados de clientes protegidos**:
   - Removida política pública `"Public can view orders"`
   - Apenas admin autenticado pode visualizar pedidos
   - INSERT público mantido apenas para checkout funcionar

2. **Informações sensíveis**:
   - CPF, email, telefone, endereço: **protegidos** ✅
   - PIX QR codes: **protegidos** ✅
   - Dados de pagamento: **protegidos** ✅

### ⚠️ Próximos Passos de Segurança

1. **Criar usuário admin**:
   - Use Supabase Auth para criar conta
   - Guarde bem as credenciais

2. **Desabilitar cadastro público** (opcional):
   - Settings → Authentication → Disable sign-ups
   - Apenas você terá acesso ao admin

3. **Ativar RLS em TODAS as tabelas**:
   - Já configurado no script ✅

---

## 📊 Verificação Final

Execute este checklist:

- [ ] Projeto Supabase criado
- [ ] Tabelas criadas com `01-create-tables.sql`
- [ ] Dados exportados do Lovable Cloud
- [ ] Dados importados no Supabase
- [ ] Edge function `arkama-integration` deployada
- [ ] Secret `ARKAMA_API_KEY` configurado
- [ ] Arquivo `.env` atualizado com novas credenciais
- [ ] Login admin funciona
- [ ] Dashboard mostra pedidos
- [ ] Checkout cria novos pedidos
- [ ] PIX gera QR code
- [ ] Produtos podem ser gerenciados
- [ ] Cupons podem ser criados e aplicados

---

## 🆘 Problemas Comuns

### "relation 'products' already exists"
✅ Normal! Significa que as tabelas já foram criadas. Pule para o próximo passo.

### "Failed to fetch"
❌ Verifique se atualizou corretamente o `.env` com as novas credenciais.

### "RLS policy violation"
❌ Certifique-se de estar logado como admin ao acessar `/dashboard`.

### Edge function retorna 500
❌ Verifique se o secret `ARKAMA_API_KEY` foi configurado corretamente.

---

## 🎉 Pronto!

Seu projeto agora está rodando no seu próprio Supabase! 

Você tem controle total sobre:
- ✅ Dados
- ✅ Backup
- ✅ Logs
- ✅ Configurações
- ✅ Billing

**Próximos passos sugeridos:**
1. Configure backups automáticos no Supabase
2. Ative 2FA na sua conta Supabase
3. Configure domínio customizado (se tiver)
4. Monitore uso e custos regularmente

---

## 📚 Recursos Úteis

- [Documentação Supabase](https://supabase.com/docs)
- [Supabase CLI](https://supabase.com/docs/guides/cli)
- [Row Level Security](https://supabase.com/docs/guides/auth/row-level-security)
- [Edge Functions](https://supabase.com/docs/guides/functions)
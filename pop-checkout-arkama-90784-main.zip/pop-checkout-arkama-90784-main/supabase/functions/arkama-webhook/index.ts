import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const payload = await req.json();
    console.log('Webhook da Arkama recebido:', JSON.stringify(payload, null, 2));

    const orderId = payload.id || payload.order_id || payload.orderId;
    const status = payload.status;

    if (!orderId || !status) {
      console.error('Webhook inválido: faltam dados', { orderId, status });
      return new Response(
        JSON.stringify({ success: false, error: 'Dados incompletos' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    console.log(`Atualizando pedido Arkama ${orderId} para status ${status}`);

    // Buscar pedido pelo arkama_order_id
    const { data: order, error: findError } = await supabase
      .from('orders')
      .select('id, order_number, arkama_status')
      .eq('arkama_order_id', orderId)
      .single();

    if (findError || !order) {
      console.error('Pedido não encontrado:', orderId, findError);
      return new Response(
        JSON.stringify({ success: false, error: 'Pedido não encontrado' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 404 }
      );
    }

    console.log(`Pedido encontrado: ${order.order_number}, status atual: ${order.arkama_status}`);

    // Preparar dados de atualização
    const updateData: any = {
      arkama_status: status,
    };

    // Atualizar payment_status conforme o status da Arkama
    if (status === 'PAID') {
      updateData.payment_status = 'completed';
    } else if (['CANCELED', 'REFUSED', 'REFUNDED', 'CHARGEDBACK'].includes(status)) {
      updateData.payment_status = 'failed';
    }

    // Atualizar pedido
    const { error: updateError } = await supabase
      .from('orders')
      .update(updateData)
      .eq('id', order.id);

    if (updateError) {
      console.error('Erro ao atualizar pedido:', updateError);
      throw updateError;
    }

    console.log(`Pedido ${order.order_number} atualizado com sucesso para ${status}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Pedido atualizado',
        order_number: order.order_number,
        status: status
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );

  } catch (error) {
    console.error('Erro no webhook da Arkama:', error);
    const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});

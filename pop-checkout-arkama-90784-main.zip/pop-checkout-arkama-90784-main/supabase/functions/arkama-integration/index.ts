import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const arkanaApiKey = Deno.env.get('ARKAMA_API_KEY');
    
    if (!arkanaApiKey) {
      console.error('ARKAMA_API_KEY não está configurada');
      throw new Error('ARKAMA_API_KEY não configurada');
    }

    // Verificar se há corpo na requisição
    const requestContentType = req.headers.get('content-type');
    if (!requestContentType || !requestContentType.includes('application/json')) {
      console.error('Requisição sem Content-Type application/json:', requestContentType);
      throw new Error('Content-Type deve ser application/json');
    }

    const text = await req.text();
    console.log('Body recebido (raw):', text);
    
    if (!text || text.trim() === '') {
      console.error('Body da requisição está vazio');
      throw new Error('Body da requisição está vazio');
    }

    let requestBody;
    try {
      requestBody = JSON.parse(text);
    } catch (parseError) {
      console.error('Erro ao parsear JSON:', parseError);
      console.error('Texto recebido:', text);
      throw new Error('JSON inválido no body da requisição');
    }

    const { action, data } = requestBody;
    console.log('Arkama request:', { action, data });

    // Configure a URL base da API da Arkama
    const ARKAMA_API_URL = 'https://app.arkama.com.br/api/v1';
    
    let response;
    
    switch (action) {
      case 'create_payment':
        response = await fetch(`${ARKAMA_API_URL}/orders`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${arkanaApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(data),
        });
        break;
        
      case 'check_payment':
        response = await fetch(`${ARKAMA_API_URL}/orders/${data.paymentId}`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${arkanaApiKey}`,
            'Content-Type': 'application/json',
          },
        });
        break;
        
      default:
        throw new Error(`Ação não suportada: ${action}`);
    }

    const responseContentType = response.headers.get('content-type') || '';
    let responseBody: any;

    try {
      if (responseContentType.toLowerCase().includes('application/json')) {
        responseBody = await response.json();
      } else {
        const text = await response.text();
        responseBody = { raw: text };
      }
    } catch (parseErr) {
      console.error('Falha ao parsear resposta da Arkama:', parseErr);
      const text = await response.text().catch(() => '');
      responseBody = { raw: text };
    }

    console.log('Arkama response (normalized):', responseBody);

    if (!response.ok) {
      return new Response(
        JSON.stringify({
          error: 'Arkama API error',
          status: response.status,
          body: responseBody,
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: response.status,
        }
      );
    }

    return new Response(
      JSON.stringify(responseBody),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: response.status 
      }
    );

  } catch (error) {
    console.error('Erro na integração com Arkama:', error);
    const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        details: 'Erro ao processar requisição com Arkama'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});

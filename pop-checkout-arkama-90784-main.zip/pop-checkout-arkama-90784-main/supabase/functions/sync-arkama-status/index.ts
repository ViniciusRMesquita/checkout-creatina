import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const arkanaApiKey = Deno.env.get('ARKAMA_API_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    if (!arkanaApiKey) {
      throw new Error('ARKAMA_API_KEY não configurada');
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    console.log('Iniciando sincronização de status da Arkama...');
    
    // Buscar pedidos que tem arkama_order_id e não estão com status final
    const { data: orders, error: ordersError } = await supabase
      .from('orders')
      .select('id, arkama_order_id, arkama_status, order_number')
      .not('arkama_order_id', 'is', null)
      .not('arkama_status', 'in', '("PAID","CANCELED","REFUSED","CHARGEDBACK","REFUNDED")');

    if (ordersError) {
      console.error('Erro ao buscar pedidos:', ordersError);
      throw ordersError;
    }

    console.log(`Encontrados ${orders?.length || 0} pedidos para sincronizar`);

    const ARKAMA_API_URL = 'https://app.arkama.com.br/api/v1';
    let updatedCount = 0;
    let errorCount = 0;

    // Sincronizar cada pedido
    for (const order of orders || []) {
      try {
        console.log(`Verificando pedido ${order.order_number} (Arkama ID: ${order.arkama_order_id})`);
        
        const response = await fetch(`${ARKAMA_API_URL}/orders/${order.arkama_order_id}`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${arkanaApiKey}`,
            'Content-Type': 'application/json',
          },
        });

        if (!response.ok) {
          console.error(`Erro ao consultar pedido ${order.arkama_order_id}: ${response.status}`);
          errorCount++;
          continue;
        }

        const arkmaData = await response.json();
        const newStatus = arkmaData.status;

        // Atualizar apenas se o status mudou
        if (newStatus && newStatus !== order.arkama_status) {
          console.log(`Atualizando pedido ${order.order_number}: ${order.arkama_status} → ${newStatus}`);
          
          const updateData: any = {
            arkama_status: newStatus,
          };

          // Se foi pago, atualizar payment_status também
          if (newStatus === 'PAID') {
            updateData.payment_status = 'completed';
          } else if (['CANCELED', 'REFUSED', 'REFUNDED'].includes(newStatus)) {
            updateData.payment_status = 'failed';
          }

          const { error: updateError } = await supabase
            .from('orders')
            .update(updateData)
            .eq('id', order.id);

          if (updateError) {
            console.error(`Erro ao atualizar pedido ${order.order_number}:`, updateError);
            errorCount++;
          } else {
            updatedCount++;
          }
        } else {
          console.log(`Pedido ${order.order_number} já está atualizado: ${newStatus}`);
        }
      } catch (error) {
        console.error(`Erro ao processar pedido ${order.order_number}:`, error);
        errorCount++;
      }
    }

    console.log(`Sincronização concluída: ${updatedCount} atualizados, ${errorCount} erros`);

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Sincronização concluída',
        total: orders?.length || 0,
        updated: updatedCount,
        errors: errorCount,
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Erro na sincronização com Arkama:', error);
    const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
    return new Response(
      JSON.stringify({ 
        success: false,
        error: errorMessage,
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});

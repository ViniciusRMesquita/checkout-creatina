-- Forçar regeneração de tipos
-- Adiciona e remove um comentário para disparar a sincronização
COMMENT ON TABLE public.products IS 'Tabela de produtos do e-commerce';
COMMENT ON TABLE public.coupons IS 'Tabela de cupons de desconto';
COMMENT ON TABLE public.orders IS 'Tabela de pedidos dos clientes';
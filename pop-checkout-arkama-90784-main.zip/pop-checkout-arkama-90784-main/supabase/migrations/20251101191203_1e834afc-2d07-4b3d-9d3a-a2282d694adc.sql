-- Remover política existente de visualização pública
DROP POLICY IF EXISTS "Public can view orders" ON public.orders;

-- Criar nova política que permite usuários autenticados verem todos os pedidos
CREATE POLICY "Authenticated users can view all orders" 
ON public.orders 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

-- Também permitir visualização pública (para o checkout funcionar sem autenticação)
CREATE POLICY "Anyone can view orders" 
ON public.orders 
FOR SELECT 
USING (true);
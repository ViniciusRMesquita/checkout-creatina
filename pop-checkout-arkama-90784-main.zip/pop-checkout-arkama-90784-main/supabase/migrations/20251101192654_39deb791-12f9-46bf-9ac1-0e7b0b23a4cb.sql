-- Criar tabela de afiliados
CREATE TABLE IF NOT EXISTS public.affiliates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  code TEXT UNIQUE NOT NULL,
  commission_percentage NUMERIC NOT NULL DEFAULT 10,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Adicionar colunas em orders para afiliados e status
ALTER TABLE public.orders 
ADD COLUMN IF NOT EXISTS affiliate_code TEXT,
ADD COLUMN IF NOT EXISTS arkama_order_id TEXT,
ADD COLUMN IF NOT EXISTS arkama_status TEXT DEFAULT 'pending';

-- Habilitar RLS
ALTER TABLE public.affiliates ENABLE ROW LEVEL SECURITY;

-- Políticas para afiliados: podem ver apenas seus próprios dados
CREATE POLICY "Affiliates can view their own data"
ON public.affiliates
FOR SELECT
USING (auth.uid() = user_id);

-- Admins podem ver e gerenciar todos os afiliados (usando auth.uid() IS NOT NULL como proxy para admin)
CREATE POLICY "Authenticated users can view all affiliates"
ON public.affiliates
FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can manage affiliates"
ON public.affiliates
FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- Políticas para orders: afiliados podem ver pedidos com seu código
CREATE POLICY "Affiliates can view their orders"
ON public.orders
FOR SELECT
USING (
  affiliate_code IN (
    SELECT code FROM public.affiliates WHERE user_id = auth.uid()
  )
);

-- Trigger para updated_at
CREATE TRIGGER update_affiliates_updated_at
BEFORE UPDATE ON public.affiliates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();
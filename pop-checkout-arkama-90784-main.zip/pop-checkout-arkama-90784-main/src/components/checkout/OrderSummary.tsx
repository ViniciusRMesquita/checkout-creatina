import { useState, useEffect } from "react";
import { ShoppingCart, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Product } from "@/pages/Checkout";
import { supabase } from "@/integrations/supabase/client";
const sb = supabase as any;
import creatinaSkincare from "@/assets/creatina-skincare.png";

interface OrderSummaryProps {
  product: Product;
}

export const OrderSummary = ({ product }: OrderSummaryProps) => {
  const [coupon, setCoupon] = useState("");
  const [discount, setDiscount] = useState(0);
  const { toast } = useToast();

  const subtotal = product.price;
  const shipping = 0;
  const total = subtotal + shipping - discount;

  const applyCoupon = async () => {
    try {
      const { data, error } = await sb
        .from("coupons")
        .select("*")
        .eq("code", coupon.toUpperCase())
        .eq("is_active", true)
        .maybeSingle();

      if (error) throw error;

      if (!data) {
        toast({
          title: "Cupom inválido",
          description: "O cupom digitado não existe ou está inativo.",
          variant: "destructive",
        });
        return;
      }

      // Verificar data de validade
      const now = new Date();
      if (data.starts_at && new Date(data.starts_at) > now) {
        toast({
          title: "Cupom ainda não disponível",
          description: "Este cupom ainda não está ativo.",
          variant: "destructive",
        });
        return;
      }

      if (data.ends_at && new Date(data.ends_at) < now) {
        toast({
          title: "Cupom expirado",
          description: "Este cupom já expirou.",
          variant: "destructive",
        });
        return;
      }

      // Calcular desconto
      const discountValue = data.discount_type === "percent" 
        ? subtotal * (data.discount_value / 100)
        : data.discount_value;

      setDiscount(discountValue);
      toast({
        title: "Cupom aplicado!",
        description: `Você ganhou R$ ${discountValue.toFixed(2)} de desconto.`,
      });
    } catch (error) {
      console.error("Erro ao aplicar cupom:", error);
      toast({
        title: "Erro ao aplicar cupom",
        description: "Tente novamente.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 sticky top-6">
      <div className="flex items-center gap-2 mb-6">
        <ShoppingCart className="w-5 h-5" />
        <h3 className="font-semibold text-lg" style={{ fontFamily: 'Poppins, sans-serif' }}>
          Resumo
        </h3>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-3 pb-4 border-b border-border">
          <img
            src={creatinaSkincare}
            alt={product.title}
            className="w-16 h-16 rounded-lg object-cover"
          />
          <div className="flex-1">
            <p className="font-medium text-sm">{product.title}</p>
            <p className="text-xs text-muted-foreground">Quantidade: 1</p>
          </div>
        </div>

        <div>
          <p className="text-sm font-medium mb-2">Tem cupom?</p>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Cupom de desconto"
                value={coupon}
                onChange={(e) => setCoupon(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button onClick={applyCoupon} className="bg-primary hover:bg-primary/90">
              Aplicar
            </Button>
          </div>
        </div>

        <div className="space-y-2 pt-4 border-t border-border">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Subtotal</span>
            <span className="font-medium">R$ {subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Frete</span>
            <span className="font-medium text-accent">GRÁTIS</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Desconto</span>
              <span className="font-medium text-accent">- R$ {discount.toFixed(2)}</span>
            </div>
          )}
        </div>

        <div className="pt-4 border-t border-border">
          <div className="flex justify-between items-center">
            <span className="font-semibold">Total:</span>
            <div className="text-right">
              <p className="text-2xl font-bold text-primary">R$ {total.toFixed(2)}</p>
              <p className="text-xs text-muted-foreground">Em até 12x de R$ {(total / 12).toFixed(2)}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

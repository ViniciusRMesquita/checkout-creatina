import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { StepCard } from "./StepCard";
import { validateCPF } from "@/lib/validators";

const identificationSchema = z.object({
  name: z.string().min(3, "Nome deve ter pelo menos 3 caracteres").max(100),
  email: z.string().email("Email inválido").max(255),
  cellphone: z.string().min(14, "Celular inválido").max(15),
  document: z.string().refine(validateCPF, "CPF inválido"),
});

type IdentificationFormData = z.infer<typeof identificationSchema>;

interface StepIdentificationProps {
  isActive: boolean;
  isCompleted: boolean;
  data: IdentificationFormData;
  onComplete: (data: IdentificationFormData) => void;
  onEdit: () => void;
}

export const StepIdentification = ({ isActive, isCompleted, data, onComplete, onEdit }: StepIdentificationProps) => {
  const form = useForm<IdentificationFormData>({
    resolver: zodResolver(identificationSchema),
    defaultValues: data,
  });

  const formatCellphone = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 10) {
      return numbers.replace(/(\d{2})(\d{4})(\d{0,4})/, "($1)$2-$3");
    }
    return numbers.replace(/(\d{2})(\d{5})(\d{0,4})/, "($1)$2-$3");
  };

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{0,2})/, "$1.$2.$3-$4");
  };

  const onSubmit = (formData: IdentificationFormData) => {
    onComplete(formData);
  };

  return (
    <StepCard
      stepNumber={1}
      title="Identifique-se"
      description="Solicitamos apenas informações essenciais para processar a sua compra."
      isActive={isActive}
      isCompleted={isCompleted}
      onEdit={onEdit}
      completedData={isCompleted ? data : undefined}
    >
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome completo</FormLabel>
                <FormControl>
                  <Input placeholder="Digite seu nome completo" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input type="email" placeholder="Digite seu e-mail" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="cellphone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Celular / WhatsApp</FormLabel>
                <FormControl>
                  <Input
                    placeholder="(00)00000-0000"
                    {...field}
                    onChange={(e) => field.onChange(formatCellphone(e.target.value))}
                    maxLength={15}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="document"
            render={({ field }) => (
              <FormItem>
                <FormLabel>CPF</FormLabel>
                <FormControl>
                  <Input
                    placeholder="000.000.000-00"
                    {...field}
                    onChange={(e) => field.onChange(formatCPF(e.target.value))}
                    maxLength={14}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button type="submit" className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
            Continuar
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </form>
      </Form>
    </StepCard>
  );
};

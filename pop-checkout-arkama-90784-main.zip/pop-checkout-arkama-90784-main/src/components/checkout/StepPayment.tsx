import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { CreditCard, Barcode, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { StepCard } from "./StepCard";
import { CheckoutData, Product } from "@/pages/Checkout";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const sb = supabase as any;

interface StepPaymentProps {
  isActive: boolean;
  data: CheckoutData["payment"];
  onChange: (data: CheckoutData["payment"]) => void;
  checkoutData: CheckoutData;
  product: Product;
}

export const StepPayment = ({ isActive, data, onChange, checkoutData, product }: StepPaymentProps) => {
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [pixQrCode, setPixQrCode] = useState<string | null>(null);
  const [orderId, setOrderId] = useState<string | null>(null);
  const [orderNumber, setOrderNumber] = useState<string | null>(null);
  const { toast } = useToast();

  // Polling para verificar status do pagamento
  useEffect(() => {
    if (!orderId) return;

    const checkPaymentStatus = async () => {
      try {
        // Chamar a função de sincronização primeiro
        await supabase.functions.invoke('sync-arkama-status');

        // Depois verificar o status no banco
        const { data: order, error } = await sb
          .from("orders")
          .select("arkama_status, order_number")
          .eq("id", orderId)
          .single();

        if (error) throw error;

        if (order?.arkama_status === "PAID") {
          toast({
            title: "Pagamento confirmado!",
            description: "Redirecionando...",
          });
          navigate(`/thank-you?order=${order.order_number}`);
        }
      } catch (error) {
        console.error("Erro ao verificar status:", error);
      }
    };

    // Verificar a cada 5 segundos
    const interval = setInterval(checkPaymentStatus, 5000);
    // Verificar imediatamente
    checkPaymentStatus();

    return () => clearInterval(interval);
  }, [orderId, navigate, toast]);

  const handlePaymentMethodChange = (method: "pix" | "credit" | "boleto") => {
    onChange({ method });
    setPixQrCode(null);
  };

  const processPayment = async () => {
    setIsProcessing(true);
    
    try {
      if (product.price < 2) {
        toast({
          title: "Valor mínimo para pagamento é R$ 2,00",
          description: "Atualize o preço do produto para continuar.",
          variant: "destructive",
        });
        setIsProcessing(false);
        return;
      }
      
      // Capturar código de afiliado da URL
      const urlParams = new URLSearchParams(window.location.search);
      const affiliateCode = urlParams.get("ref");
      
      const orderNumber = `PED-${Date.now()}`;

      // Normalizações necessárias para a Arkama
      const sanitizedDocument = checkoutData.identification.document.replace(/\D/g, "");
      
      // Formatar celular para o padrão brasileiro: (DD)NNNNN-NNNN
      const cellphoneDigits = checkoutData.identification.cellphone.replace(/\D/g, "");
      const formattedCellphone = cellphoneDigits.length === 11
        ? `(${cellphoneDigits.slice(0, 2)})${cellphoneDigits.slice(2, 7)}-${cellphoneDigits.slice(7)}`
        : checkoutData.identification.cellphone;

      // Preparar dados para a Arkama
      const arkmaPaymentData = {
        customer: {
          name: checkoutData.identification.name,
          email: checkoutData.identification.email,
          cellphone: formattedCellphone,
          document: sanitizedDocument,
        },
        items: [
          {
            isDigital: true,
            title: product.title,
            unitPrice: product.price,
            quantity: 1,
          },
        ],
        utms: {},
        value: product.price,
        paymentMethod: data.method,
        ip: "147.161.128.191",
      };

      let generatedPixQrCode = null;
      let arkmaOrderId = null;
      let arkmaStatus = "PENDING";

      // Chamar a edge function da Arkama
      if (data.method === "pix") {
        console.log("Enviando dados para Arkama:", arkmaPaymentData);
        
        const { data: arkmaResponse, error: arkmaError } = await supabase.functions.invoke(
          'arkama-integration',
          {
            body: {
              action: 'create_payment',
              data: arkmaPaymentData,
            },
          }
        );

        console.log("Resposta da Arkama:", { arkmaResponse, arkmaError });

        if (arkmaError) {
          console.error("Erro ao chamar Arkama:", arkmaError);
          throw new Error(`Erro ao gerar pagamento Pix: ${arkmaError.message || 'Erro desconhecido'}`);
        }

        // Verificar se há erro na resposta da Arkama
        if (arkmaResponse?.error) {
          console.error("Erro retornado pela Arkama:", arkmaResponse);
          const errorMsg = arkmaResponse.body?.message || arkmaResponse.error || "Erro ao processar pagamento";
          throw new Error(errorMsg);
        }

        console.log("Resposta da Arkama processada:", arkmaResponse);
        
        // Extrair ID do pedido e QR code da Arkama
        arkmaOrderId = arkmaResponse?.id || null;
        arkmaStatus = arkmaResponse?.status || "PENDING";
        
        generatedPixQrCode =
          arkmaResponse?.pix?.payload ||
          arkmaResponse?.qrCode ||
          arkmaResponse?.pix_qr_code ||
          arkmaResponse?.payload ||
          null;
      }

      // Salvar pedido no Supabase
      const orderData: any = {
        customer_name: checkoutData.identification.name,
        customer_email: checkoutData.identification.email,
        customer_cpf: sanitizedDocument,
        customer_phone: formattedCellphone,
        delivery_zipcode: checkoutData.delivery.cep,
        delivery_address: checkoutData.delivery.street,
        delivery_number: checkoutData.delivery.number,
        delivery_complement: checkoutData.delivery.complement,
        delivery_neighborhood: checkoutData.delivery.neighborhood,
        delivery_city: checkoutData.delivery.city,
        delivery_state: checkoutData.delivery.state,
        payment_method: data.method,
        payment_status: "pending",
        subtotal: product.price,
        shipping: 0,
        total: product.price,
        pix_qr_code: generatedPixQrCode,
        order_number: orderNumber,
      };

      // Adicionar dados do afiliado e Arkama se disponíveis
      if (affiliateCode) {
        orderData.affiliate_code = affiliateCode;
      }
      if (data.method === "pix" && arkmaOrderId) {
        orderData.arkama_order_id = arkmaOrderId;
        orderData.arkama_status = arkmaStatus;
      }

      const { data: savedOrder, error: dbError } = await sb
        .from("orders")
        .insert(orderData)
        .select()
        .single();

      if (dbError) {
        console.error("Erro ao salvar pedido:", dbError);
        throw new Error("Erro ao salvar pedido no banco de dados");
      }

      console.log("Pedido salvo com sucesso:", savedOrder);

      // Salvar ID do pedido para polling
      setOrderId(savedOrder.id);
      setOrderNumber(orderNumber);

      // Exibir resultado
      if (data.method === "pix" && generatedPixQrCode) {
        setPixQrCode(generatedPixQrCode);
        toast({
          title: "Pix gerado com sucesso!",
          description: `Pedido #${orderNumber} registrado. Aguardando pagamento...`,
        });
      } else {
        toast({
          title: "Pagamento processado!",
          description: `Pedido #${orderNumber} registrado com sucesso.`,
        });
        navigate(`/thank-you?order=${orderNumber}`);
      }
      
      setIsProcessing(false);
    } catch (error: any) {
      console.error("Erro ao processar pagamento:", error);
      toast({
        title: "Erro ao processar pagamento",
        description: error?.message || "Ocorreu um erro. Tente novamente.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  return (
    <StepCard
      stepNumber={3}
      title="Pagamento"
      description="Escolha uma forma de Pagamento."
      isActive={isActive}
      isCompleted={false}
      onEdit={() => {}}
    >
      <div className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => handlePaymentMethodChange("pix")}
            className={`p-4 border-2 rounded-lg flex flex-col items-center justify-center gap-2 transition-all ${
              data.method === "pix"
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary/50"
            }`}
          >
            <Smartphone className="w-6 h-6" />
            <span className="text-sm font-medium">Pix</span>
          </button>

          <button
            onClick={() => handlePaymentMethodChange("credit")}
            className={`p-4 border-2 rounded-lg flex flex-col items-center justify-center gap-2 transition-all ${
              data.method === "credit"
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary/50"
            }`}
          >
            <CreditCard className="w-6 h-6" />
            <span className="text-sm font-medium">Cartão</span>
          </button>

          <button
            onClick={() => handlePaymentMethodChange("boleto")}
            className={`p-4 border-2 rounded-lg flex flex-col items-center justify-center gap-2 transition-all ${
              data.method === "boleto"
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary/50"
            }`}
          >
            <Barcode className="w-6 h-6" />
            <span className="text-sm font-medium">Boleto</span>
          </button>
        </div>

        {pixQrCode && (
          <div className="p-6 bg-card border border-border rounded-lg text-center space-y-4">
            <div>
              <p className="mb-4 font-medium">Escaneie o QR Code para pagar</p>
              <div className="bg-white p-4 inline-block rounded-lg">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(pixQrCode)}`}
                  alt="QR Code Pix"
                  className="w-48 h-48"
                />
              </div>
              <p className="mt-4 text-sm text-muted-foreground">
                Ou copie o código Pix:
              </p>
              <code className="block mt-2 p-2 bg-muted rounded text-xs break-all">
                {pixQrCode}
              </code>
            </div>
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
              <span>Aguardando confirmação do pagamento...</span>
            </div>
          </div>
        )}

        <Button
          onClick={processPayment}
          disabled={isProcessing}
          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
        >
          {isProcessing ? "Processando..." : "Finalizar Compra"}
        </Button>

      </div>
    </StepCard>
  );
};

import { Shield } from "lucide-react";

export const CheckoutHeader = () => {
  return (
    <header className="bg-card border-b border-border py-4">
      <div className="container mx-auto px-4 max-w-7xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="text-primary font-bold text-2xl" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Creatina Skincare
          </div>
        </div>
        <div className="flex items-center gap-2 text-accent">
          <Shield className="w-5 h-5" />
          <div className="text-sm font-medium">
            <div className="uppercase text-xs">Pagamento</div>
            <div className="font-semibold">100% Seguro</div>
          </div>
        </div>
      </div>
    </header>
  );
};

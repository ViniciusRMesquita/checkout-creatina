export const CheckoutFooter = () => {
  return (
    <footer className="bg-card border-t border-border py-6 mt-12">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="flex flex-col items-center justify-center gap-4">
          <p className="text-sm text-muted-foreground text-center">
            Pagamento 100% seguro e criptografado
          </p>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Mastercard_2019_logo.svg/200px-Mastercard_2019_logo.svg.png" 
              alt="Mastercard" 
              className="h-8 object-contain" 
            />
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/200px-Visa_Inc._logo.svg.png" 
              alt="Visa" 
              className="h-8 object-contain" 
            />
            <img 
              src="https://logospng.org/download/elo/logo-elo-256.png" 
              alt="Elo" 
              className="h-8 object-contain" 
            />
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/American_Express_logo_%282018%29.svg/200px-American_Express_logo_%282018%29.svg.png" 
              alt="American Express" 
              className="h-8 object-contain" 
            />
          </div>
          <p className="text-xs text-muted-foreground text-center">
            © 2025 Creatina Skincare. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

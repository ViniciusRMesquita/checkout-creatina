import { ReactNode } from "react";
import { CheckCircle, Edit2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface StepCardProps {
  stepNumber: number;
  title: string;
  description: string;
  isActive: boolean;
  isCompleted: boolean;
  onEdit: () => void;
  children?: ReactNode;
  completedData?: any;
}

export const StepCard = ({
  stepNumber,
  title,
  description,
  isActive,
  isCompleted,
  onEdit,
  children,
  completedData,
}: StepCardProps) => {
  return (
    <div
      className={`bg-card rounded-xl border transition-all duration-300 ${
        isActive
          ? "border-primary shadow-lg"
          : isCompleted
          ? "border-accent"
          : "border-border"
      }`}
    >
      <div className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${
              isCompleted
                ? "bg-accent text-accent-foreground"
                : isActive
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground"
            }`}
          >
            {isCompleted ? <CheckCircle className="w-5 h-5" /> : stepNumber}
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-lg" style={{ fontFamily: 'Poppins, sans-serif' }}>
              {title}
            </h3>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
          {isCompleted && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onEdit}
              className="text-primary hover:text-primary"
            >
              <Edit2 className="w-4 h-4" />
            </Button>
          )}
        </div>

        {isCompleted && completedData && !isActive && (
          <div className="pl-[52px] space-y-1 text-sm">
            {Object.entries(completedData).map(([key, value]) => (
              value && (
                <div key={key} className="text-muted-foreground">
                  <span className="capitalize">{key.replace(/([A-Z])/g, " $1")}: </span>
                  <span className="text-foreground">{String(value)}</span>
                </div>
              )
            ))}
          </div>
        )}

        {isActive && children && <div className="pl-[52px] mt-4">{children}</div>}
      </div>
    </div>
  );
};

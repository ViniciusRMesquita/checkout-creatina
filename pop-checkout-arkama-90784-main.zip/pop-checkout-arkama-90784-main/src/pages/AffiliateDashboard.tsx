import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
const sb = supabase as any;
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { DollarSign, Package, TrendingUp, LogOut, Link, Check } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

type Order = {
  id: string;
  order_number: string;
  customer_name: string;
  total: number;
  arkama_status: string | null;
  created_at: string;
};

type AffiliateData = {
  code: string;
  commission_percentage: number;
  name: string;
};

type Product = {
  id: string;
  title: string;
  description: string | null;
  price: number;
  image_url: string | null;
  is_active: boolean;
};

const AffiliateDashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [affiliate, setAffiliate] = useState<AffiliateData | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    checkAuthAndFetch();
  }, []);

  const checkAuthAndFetch = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/auth");
        return;
      }

      // Buscar dados do afiliado
      const { data: affiliateData, error: affiliateError } = await sb
        .from("affiliates")
        .select("code, commission_percentage, name")
        .eq("user_id", session.user.id)
        .single();

      if (affiliateError) {
        toast({
          title: "Você não é um afiliado",
          description: "Entre em contato com o administrador",
          variant: "destructive",
        });
        navigate("/");
        return;
      }

      setAffiliate(affiliateData);

      // Buscar pedidos do afiliado
      const { data: ordersData, error: ordersError } = await sb
        .from("orders")
        .select("id, order_number, customer_name, total, arkama_status, created_at")
        .eq("affiliate_code", affiliateData.code)
        .order("created_at", { ascending: false });

      if (ordersError) throw ordersError;
      setOrders(ordersData || []);

      // Buscar produtos ativos
      const { data: productsData, error: productsError } = await sb
        .from("products")
        .select("*")
        .eq("is_active", true)
        .order("created_at", { ascending: false });

      if (productsError) throw productsError;
      setProducts(productsData || []);
    } catch (error) {
      console.error("Erro ao buscar dados:", error);
      toast({
        title: "Erro ao carregar dados",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/auth");
  };

  const getStatusBadge = (status: string | null) => {
    if (!status) return <Badge variant="secondary">Pendente</Badge>;

    const statusConfig: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; label: string }> = {
      UNDEFINED: { variant: "secondary", label: "Indefinido" },
      PENDING: { variant: "secondary", label: "Pendente" },
      PAID: { variant: "default", label: "Pago" },
      CANCELED: { variant: "destructive", label: "Cancelado" },
      REFUSED: { variant: "destructive", label: "Recusado" },
      CHARGEDBACK: { variant: "destructive", label: "Estornado" },
      REFUNDED: { variant: "destructive", label: "Reembolsado" },
      IN_ANALYSIS: { variant: "outline", label: "Em Análise" },
      IN_DISPUTE: { variant: "outline", label: "Em Disputa" },
      PROCESSING: { variant: "secondary", label: "Processando" },
      PRE_CHARGEDBACK: { variant: "destructive", label: "Pré-Estorno" },
    };

    const config = statusConfig[status] || { variant: "secondary" as const, label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const calculateStats = () => {
    const paidOrders = orders.filter((o) => o.arkama_status === "PAID");
    const totalSales = paidOrders.reduce((sum, o) => sum + Number(o.total), 0);
    const totalCommission = totalSales * (affiliate?.commission_percentage || 0) / 100;

    return {
      totalOrders: orders.length,
      paidOrders: paidOrders.length,
      totalSales,
      totalCommission,
    };
  };

  const copyCheckoutLink = (productId: string) => {
    const link = `${window.location.origin}/checkout?product=${productId}&ref=${affiliate?.code}`;
    navigator.clipboard.writeText(link);
    setCopiedId(productId);
    toast({ title: "Link copiado!", description: "Compartilhe para ganhar comissão" });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const stats = affiliate ? calculateStats() : null;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p>Carregando...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Dashboard do Afiliado</h1>
            <p className="text-muted-foreground">
              Bem-vindo, {affiliate?.name}! Código: <span className="font-mono">{affiliate?.code}</span>
            </p>
          </div>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="w-4 h-4 mr-2" />
            Sair
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <Package className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total de Vendas</p>
                <p className="text-2xl font-bold">{stats?.totalOrders || 0}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-500/10 rounded-lg">
                <TrendingUp className="w-6 h-6 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Vendas Pagas</p>
                <p className="text-2xl font-bold">{stats?.paidOrders || 0}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-500/10 rounded-lg">
                <DollarSign className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total em Vendas</p>
                <p className="text-2xl font-bold">R$ {stats?.totalSales.toFixed(2) || "0.00"}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-yellow-500/10 rounded-lg">
                <DollarSign className="w-6 h-6 text-yellow-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Comissão ({affiliate?.commission_percentage}%)</p>
                <p className="text-2xl font-bold">R$ {stats?.totalCommission.toFixed(2) || "0.00"}</p>
              </div>
            </div>
          </Card>
        </div>

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Suas Vendas</h2>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pedido</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Comissão</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Data</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      Nenhuma venda ainda
                    </TableCell>
                  </TableRow>
                ) : (
                  orders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-mono">{order.order_number}</TableCell>
                      <TableCell>{order.customer_name}</TableCell>
                      <TableCell>R$ {Number(order.total).toFixed(2)}</TableCell>
                      <TableCell className="font-bold text-primary">
                        R$ {(Number(order.total) * (affiliate?.commission_percentage || 0) / 100).toFixed(2)}
                      </TableCell>
                      <TableCell>{getStatusBadge(order.arkama_status)}</TableCell>
                      <TableCell>{new Date(order.created_at).toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Produtos Disponíveis</h2>
          <p className="text-sm text-muted-foreground mb-4">
            Copie os links abaixo para divulgar e ganhar comissão em cada venda
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {products.length === 0 ? (
              <div className="col-span-full text-center text-muted-foreground py-8">
                Nenhum produto disponível no momento
              </div>
            ) : (
              products.map((product) => (
                <Card key={product.id} className="p-4 space-y-3">
                  {product.image_url && (
                    <img
                      src={product.image_url}
                      alt={product.title}
                      className="w-full h-40 object-cover rounded"
                    />
                  )}
                  <div>
                    <h3 className="font-semibold">{product.title}</h3>
                    {product.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {product.description}
                      </p>
                    )}
                    <p className="text-lg font-bold text-primary mt-2">
                      R$ {product.price.toFixed(2)}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Sua comissão: R$ {(product.price * (affiliate?.commission_percentage || 0) / 100).toFixed(2)}
                    </p>
                  </div>
                  <Button
                    variant="default"
                    size="sm"
                    className="w-full gap-2"
                    onClick={() => copyCheckoutLink(product.id)}
                  >
                    {copiedId === product.id ? (
                      <>
                        <Check className="w-4 h-4" />
                        Link Copiado!
                      </>
                    ) : (
                      <>
                        <Link className="w-4 h-4" />
                        Copiar Link
                      </>
                    )}
                  </Button>
                </Card>
              ))
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default AffiliateDashboard;

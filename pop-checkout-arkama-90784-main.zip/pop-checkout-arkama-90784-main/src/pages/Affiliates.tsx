import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
const sb = supabase as any;
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Plus, Edit, Trash2, Link as LinkIcon, Check } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";

type Affiliate = {
  id: string;
  name: string;
  email: string;
  code: string;
  commission_percentage: number;
  is_active: boolean;
};

const Affiliates = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingAffiliate, setEditingAffiliate] = useState<Affiliate | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    code: "",
    commission_percentage: "10",
    is_active: true,
  });

  useEffect(() => {
    checkAuth();
    fetchAffiliates();
  }, []);

  const checkAuth = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      navigate("/auth");
    }
  };

  const fetchAffiliates = async () => {
    try {
      const { data, error } = await sb
        .from("affiliates")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setAffiliates(data || []);
    } catch (error) {
      console.error("Erro ao buscar afiliados:", error);
      toast({
        title: "Erro ao carregar afiliados",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const affiliateData = {
        name: formData.name,
        email: formData.email,
        code: formData.code.toUpperCase(),
        commission_percentage: parseFloat(formData.commission_percentage),
        is_active: formData.is_active,
      };

      if (editingAffiliate) {
        const { error } = await sb
          .from("affiliates")
          .update(affiliateData)
          .eq("id", editingAffiliate.id);

        if (error) throw error;

        toast({ title: "Afiliado atualizado com sucesso!" });
      } else {
        const { error } = await sb
          .from("affiliates")
          .insert([affiliateData]);

        if (error) throw error;

        toast({ title: "Afiliado criado com sucesso!" });
      }

      setIsDialogOpen(false);
      resetForm();
      fetchAffiliates();
    } catch (error: any) {
      console.error("Erro ao salvar afiliado:", error);
      toast({
        title: "Erro ao salvar afiliado",
        description: error.message || "Código ou email já existem",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este afiliado?")) return;

    try {
      const { error } = await sb
        .from("affiliates")
        .delete()
        .eq("id", id);

      if (error) throw error;

      toast({ title: "Afiliado excluído com sucesso!" });
      fetchAffiliates();
    } catch (error) {
      console.error("Erro ao excluir afiliado:", error);
      toast({
        title: "Erro ao excluir afiliado",
        variant: "destructive",
      });
    }
  };

  const openEditDialog = (affiliate: Affiliate) => {
    setEditingAffiliate(affiliate);
    setFormData({
      name: affiliate.name,
      email: affiliate.email,
      code: affiliate.code,
      commission_percentage: affiliate.commission_percentage.toString(),
      is_active: affiliate.is_active,
    });
    setIsDialogOpen(true);
  };

  const resetForm = () => {
    setEditingAffiliate(null);
    setFormData({
      name: "",
      email: "",
      code: "",
      commission_percentage: "10",
      is_active: true,
    });
  };

  const copyAffiliateLink = (code: string) => {
    const link = `${window.location.origin}/checkout?ref=${code}`;
    navigator.clipboard.writeText(link);
    setCopiedCode(code);
    toast({ title: "Link copiado!", description: "Envie para o afiliado divulgar" });
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Gerenciar Afiliados</h1>
              <p className="text-muted-foreground">Configure afiliados e comissões</p>
            </div>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Novo Afiliado
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingAffiliate ? "Editar Afiliado" : "Novo Afiliado"}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="code">Código (único)</Label>
                  <Input
                    id="code"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                    placeholder="Ex: JOAO, MARIA10"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="commission">Comissão (%)</Label>
                  <Input
                    id="commission"
                    type="number"
                    step="0.01"
                    min="0"
                    max="100"
                    value={formData.commission_percentage}
                    onChange={(e) => setFormData({ ...formData, commission_percentage: e.target.value })}
                    required
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                  <Label htmlFor="is_active">Afiliado Ativo</Label>
                </div>
                <Button type="submit" className="w-full">
                  {editingAffiliate ? "Atualizar" : "Criar"} Afiliado
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {isLoading ? (
            <Card className="p-6">Carregando...</Card>
          ) : affiliates.length === 0 ? (
            <Card className="p-6 col-span-full text-center">
              Nenhum afiliado cadastrado
            </Card>
          ) : (
            affiliates.map((affiliate) => (
              <Card key={affiliate.id} className="p-6 space-y-4">
                <div>
                  <h3 className="font-semibold text-lg">{affiliate.name}</h3>
                  <p className="text-sm text-muted-foreground">{affiliate.email}</p>
                  <p className="text-sm font-mono bg-muted px-2 py-1 rounded mt-2 inline-block">
                    {affiliate.code}
                  </p>
                  <p className="text-xl font-bold text-primary mt-2">
                    {affiliate.commission_percentage}% comissão
                  </p>
                  <p className="text-sm mt-1">
                    Status:{" "}
                    <span className={affiliate.is_active ? "text-green-500" : "text-red-500"}>
                      {affiliate.is_active ? "Ativo" : "Inativo"}
                    </span>
                  </p>
                </div>
                <div className="space-y-2">
                  <Button
                    variant="default"
                    size="sm"
                    className="w-full gap-2"
                    onClick={() => copyAffiliateLink(affiliate.code)}
                  >
                    {copiedCode === affiliate.code ? (
                      <>
                        <Check className="w-4 h-4" />
                        Link Copiado!
                      </>
                    ) : (
                      <>
                        <LinkIcon className="w-4 h-4" />
                        Copiar Link
                      </>
                    )}
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => openEditDialog(affiliate)}
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDelete(affiliate.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Affiliates;

import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
const sb = supabase as any;
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Eye, Package, DollarSign, Clock, LogOut, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Session, User } from "@supabase/supabase-js";
import { SyncArkmaButton } from "@/components/dashboard/SyncArkmaButton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type Order = {
  id: string;
  order_number: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  total: number;
  payment_method: string;
  payment_status: string;
  arkama_status: string | null;
  affiliate_code: string | null;
  created_at: string;
  delivery_city: string;
  delivery_state: string;
  pix_qr_code: string | null;
  customer_cpf: string;
  delivery_zipcode: string;
  delivery_address: string;
  delivery_number: string;
  delivery_complement: string | null;
  delivery_neighborhood: string;
  tracking_code: string | null;
};

const Dashboard = () => {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [filteredOrders, setFilteredOrders] = useState<Order[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [trackingCode, setTrackingCode] = useState("");
  const { toast } = useToast();

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (!session) {
          setTimeout(() => {
            navigate("/auth");
          }, 0);
        }
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (!session) {
        navigate("/auth");
      } else {
        fetchOrders();
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    // Realtime subscription
    const channel = supabase
      .channel('orders-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders'
        },
        () => {
          fetchOrders();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    const filtered = orders.filter((order) =>
      order.order_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer_email.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredOrders(filtered);
  }, [searchTerm, orders]);

  const fetchOrders = async () => {
    try {
      const { data, error } = await sb
        .from("orders")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setOrders(data || []);
      setFilteredOrders(data || []);
    } catch (error) {
      console.error("Erro ao buscar pedidos:", error);
      toast({
        title: "Erro ao carregar pedidos",
        description: "Não foi possível carregar os pedidos.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const totalRevenue = orders.reduce((acc, order) => acc + Number(order.total), 0);
  const pendingOrders = orders.filter((o) => o.payment_status === "pending").length;
  const completedOrders = orders.filter((o) => o.payment_status === "completed").length;

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: "secondary",
      completed: "default",
      failed: "destructive",
    } as const;
    
    const labels = {
      pending: "Pendente",
      completed: "Pago",
      failed: "Falhou",
    };

    return (
      <Badge variant={variants[status as keyof typeof variants] || "secondary"}>
        {labels[status as keyof typeof labels] || status}
      </Badge>
    );
  };

  const getArkmaStatusBadge = (status: string | null) => {
    if (!status) return <Badge variant="secondary">-</Badge>;

    const statusConfig: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; label: string; color?: string }> = {
      UNDEFINED: { variant: "secondary", label: "Indefinido" },
      PENDING: { variant: "secondary", label: "Pendente", color: "bg-yellow-500" },
      PAID: { variant: "default", label: "Pago", color: "bg-green-500" },
      CANCELED: { variant: "destructive", label: "Cancelado" },
      REFUSED: { variant: "destructive", label: "Recusado" },
      CHARGEDBACK: { variant: "destructive", label: "Estornado" },
      REFUNDED: { variant: "destructive", label: "Reembolsado" },
      IN_ANALYSIS: { variant: "outline", label: "Em Análise", color: "bg-blue-500" },
      IN_DISPUTE: { variant: "outline", label: "Em Disputa", color: "bg-orange-500" },
      PROCESSING: { variant: "secondary", label: "Processando" },
      PRE_CHARGEDBACK: { variant: "destructive", label: "Pré-Estorno" },
    };

    const config = statusConfig[status] || { variant: "secondary" as const, label: status };
    
    return (
      <Badge variant={config.variant} className={config.color}>
        {config.label}
      </Badge>
    );
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleString("pt-BR");
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/auth");
  };

  const handleAddTracking = async (orderId: string) => {
    if (!trackingCode.trim()) {
      toast({
        title: "Código de rastreio vazio",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await sb
        .from("orders")
        .update({ tracking_code: trackingCode })
        .eq("id", orderId);

      if (error) throw error;

      toast({
        title: "Código de rastreio adicionado!",
      });

      setTrackingCode("");
      fetchOrders();
      
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder({ ...selectedOrder, tracking_code: trackingCode });
      }
    } catch (error) {
      console.error("Erro ao adicionar rastreio:", error);
      toast({
        title: "Erro ao adicionar rastreio",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Dashboard de Pedidos</h1>
            <p className="text-muted-foreground">Gerencie todos os pedidos da loja</p>
          </div>
          <div className="flex items-center gap-2">
            <SyncArkmaButton onSyncComplete={fetchOrders} />
            <Link to="/products">
              <Button variant="outline" className="gap-2">
                <Settings className="w-4 h-4" />
                Produtos
              </Button>
            </Link>
            <Link to="/coupons">
              <Button variant="outline" className="gap-2">
                <Settings className="w-4 h-4" />
                Cupons
              </Button>
            </Link>
            <Link to="/affiliates">
              <Button variant="outline" className="gap-2">
                <Settings className="w-4 h-4" />
                Afiliados
              </Button>
            </Link>
            <Button variant="outline" onClick={handleLogout} className="gap-2">
              <LogOut className="w-4 h-4" />
              Sair
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <Package className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total de Pedidos</p>
                <p className="text-2xl font-bold">{orders.length}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-green-500/10 rounded-lg">
                <DollarSign className="w-6 h-6 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Receita Total</p>
                <p className="text-2xl font-bold">
                  R$ {totalRevenue.toFixed(2)}
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-yellow-500/10 rounded-lg">
                <Clock className="w-6 h-6 text-yellow-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pendentes</p>
                <p className="text-2xl font-bold">{pendingOrders}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-500/10 rounded-lg">
                <Package className="w-6 h-6 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Completos</p>
                <p className="text-2xl font-bold">{completedOrders}</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Search */}
        <Card className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por número do pedido, nome ou email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </Card>

        {/* Orders Table */}
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Pedido</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Pagamento</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Afiliado</TableHead>
                <TableHead>Rastreio</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-8">
                    Carregando pedidos...
                  </TableCell>
                </TableRow>
              ) : filteredOrders.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-8">
                    Nenhum pedido encontrado
                  </TableCell>
                </TableRow>
              ) : (
                filteredOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">
                      {order.order_number}
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{order.customer_name}</p>
                        <p className="text-sm text-muted-foreground">
                          {order.customer_email}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>R$ {Number(order.total).toFixed(2)}</TableCell>
                    <TableCell className="capitalize">
                      {order.payment_method}
                    </TableCell>
                    <TableCell>
                      {order.arkama_status ? (
                        getArkmaStatusBadge(order.arkama_status)
                      ) : (
                        getStatusBadge(order.payment_status)
                      )}
                    </TableCell>
                    <TableCell>
                      {order.affiliate_code ? (
                        <Badge variant="outline">{order.affiliate_code}</Badge>
                      ) : (
                        <span className="text-muted-foreground text-sm">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {order.tracking_code ? (
                        <code className="text-xs bg-muted px-2 py-1 rounded">
                          {order.tracking_code}
                        </code>
                      ) : (
                        <span className="text-muted-foreground text-sm">-</span>
                      )}
                    </TableCell>
                    <TableCell>{formatDate(order.created_at)}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedOrder(order)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Card>
      </div>

      {/* Order Details Dialog */}
      <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalhes do Pedido {selectedOrder?.order_number}</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold mb-2">Cliente</h3>
                <div className="space-y-1 text-sm">
                  <p><strong>Nome:</strong> {selectedOrder.customer_name}</p>
                  <p><strong>Email:</strong> {selectedOrder.customer_email}</p>
                  <p><strong>Telefone:</strong> {selectedOrder.customer_phone}</p>
                  <p><strong>CPF:</strong> {selectedOrder.customer_cpf}</p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Entrega</h3>
                <div className="space-y-1 text-sm">
                  <p><strong>CEP:</strong> {selectedOrder.delivery_zipcode}</p>
                  <p><strong>Endereço:</strong> {selectedOrder.delivery_address}, {selectedOrder.delivery_number}</p>
                  {selectedOrder.delivery_complement && (
                    <p><strong>Complemento:</strong> {selectedOrder.delivery_complement}</p>
                  )}
                  <p><strong>Bairro:</strong> {selectedOrder.delivery_neighborhood}</p>
                  <p><strong>Cidade:</strong> {selectedOrder.delivery_city} - {selectedOrder.delivery_state}</p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Pagamento</h3>
                <div className="space-y-1 text-sm">
                  <p><strong>Método:</strong> {selectedOrder.payment_method.toUpperCase()}</p>
                  <p><strong>Status:</strong> {getStatusBadge(selectedOrder.payment_status)}</p>
                  {selectedOrder.arkama_status && (
                    <p><strong>Status Arkama:</strong> {getArkmaStatusBadge(selectedOrder.arkama_status)}</p>
                  )}
                  <p><strong>Total:</strong> R$ {Number(selectedOrder.total).toFixed(2)}</p>
                  {selectedOrder.affiliate_code && (
                    <p><strong>Afiliado:</strong> <Badge variant="outline">{selectedOrder.affiliate_code}</Badge></p>
                  )}
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Rastreio</h3>
                {selectedOrder.tracking_code ? (
                  <div className="space-y-1 text-sm">
                    <p><strong>Código:</strong></p>
                    <code className="block p-2 bg-muted rounded">
                      {selectedOrder.tracking_code}
                    </code>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Nenhum código de rastreio</p>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Código de rastreio"
                        value={trackingCode}
                        onChange={(e) => setTrackingCode(e.target.value)}
                      />
                      <Button onClick={() => handleAddTracking(selectedOrder.id)}>
                        Adicionar
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              {selectedOrder.pix_qr_code && (
                <div>
                  <h3 className="font-semibold mb-2">QR Code Pix</h3>
                  <div className="bg-white p-4 rounded-lg inline-block">
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(selectedOrder.pix_qr_code)}`}
                      alt="QR Code Pix"
                      className="w-48 h-48"
                    />
                  </div>
                  <code className="block mt-2 p-2 bg-muted rounded text-xs break-all">
                    {selectedOrder.pix_qr_code}
                  </code>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Dashboard;

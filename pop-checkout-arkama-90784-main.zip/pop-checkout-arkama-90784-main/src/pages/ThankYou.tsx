import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate, useSearchParams } from "react-router-dom";

const ThankYou = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const orderNumber = searchParams.get("order");

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="flex justify-center">
          <div className="rounded-full bg-accent/10 p-6">
            <CheckCircle className="w-16 h-16 text-accent" />
          </div>
        </div>
        
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Obrigado pela sua compra!</h1>
          <p className="text-muted-foreground">
            Seu pedido foi recebido com sucesso e está sendo processado.
          </p>
          {orderNumber && (
            <p className="text-lg font-semibold text-primary">
              Pedido: #{orderNumber}
            </p>
          )}
        </div>

        <div className="bg-card border border-border rounded-lg p-6 space-y-3">
          <p className="text-sm text-muted-foreground">
            Você receberá um e-mail de confirmação em breve com os detalhes do seu pedido e informações de rastreamento.
          </p>
        </div>

        <Button 
          onClick={() => navigate("/")} 
          className="w-full bg-accent hover:bg-accent/90"
        >
          Voltar ao início
        </Button>
      </div>
    </div>
  );
};

export default ThankYou;

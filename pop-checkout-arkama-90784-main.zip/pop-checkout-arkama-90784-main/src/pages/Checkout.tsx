import { useState, useEffect } from "react";
import { CheckoutHeader } from "@/components/checkout/CheckoutHeader";
import { CheckoutFooter } from "@/components/checkout/CheckoutFooter";
import { StepIdentification } from "@/components/checkout/StepIdentification";
import { StepDelivery } from "@/components/checkout/StepDelivery";
import { StepPayment } from "@/components/checkout/StepPayment";
import { OrderSummary } from "@/components/checkout/OrderSummary";
import { supabase } from "@/integrations/supabase/client";
const sb = supabase as any;
import { useToast } from "@/hooks/use-toast";

export type Product = {
  id: string;
  title: string;
  description: string | null;
  price: number;
  image_url: string | null;
};

export type CheckoutData = {
  identification: {
    name: string;
    email: string;
    cellphone: string;
    document: string;
  };
  delivery: {
    cep: string;
    street: string;
    number: string;
    complement: string;
    neighborhood: string;
    city: string;
    state: string;
  };
  payment: {
    method: "pix" | "credit" | "boleto";
  };
};

const Checkout = () => {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [checkoutData, setCheckoutData] = useState<CheckoutData>({
    identification: {
      name: "",
      email: "",
      cellphone: "",
      document: "",
    },
    delivery: {
      cep: "",
      street: "",
      number: "",
      complement: "",
      neighborhood: "",
      city: "",
      state: "",
    },
    payment: {
      method: "pix",
    },
  });

  useEffect(() => {
    fetchProduct();
  }, []);

  const getProductIdFromUrl = () => {
    const params = new URLSearchParams(window.location.search);
    return params.get("product");
  };

  const fetchProduct = async () => {
    try {
      const productId = getProductIdFromUrl();
      
      let query = sb.from("products").select("*").eq("is_active", true);
      
      if (productId) {
        // Se houver ID na URL, busca produto específico
        query = query.eq("id", productId).single();
      } else {
        // Caso contrário, busca o mais recente
        query = query.order("created_at", { ascending: false }).limit(1).single();
      }

      const { data, error } = await query;

      if (error) throw error;
      setProduct(data);
    } catch (error) {
      console.error("Erro ao buscar produto:", error);
      toast({
        title: "Erro ao carregar produto",
        description: "Produto não encontrado ou inativo.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateIdentification = (data: CheckoutData["identification"]) => {
    setCheckoutData({ ...checkoutData, identification: data });
    setCurrentStep(2);
  };

  const updateDelivery = (data: CheckoutData["delivery"]) => {
    setCheckoutData({ ...checkoutData, delivery: data });
    setCurrentStep(3);
  };

  const updatePayment = (data: CheckoutData["payment"]) => {
    setCheckoutData({ ...checkoutData, payment: data });
  };

  return (
    <div className="min-h-screen bg-background">
      <CheckoutHeader />
      
      {loading ? (
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <div className="text-center">Carregando produto...</div>
        </div>
      ) : !product ? (
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <div className="text-center">Nenhum produto disponível no momento.</div>
        </div>
      ) : (
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <StepIdentification
                isActive={currentStep === 1}
                isCompleted={currentStep > 1}
                data={checkoutData.identification}
                onComplete={updateIdentification}
                onEdit={() => setCurrentStep(1)}
              />
              
              <StepDelivery
                isActive={currentStep === 2}
                isCompleted={currentStep > 2}
                data={checkoutData.delivery}
                onComplete={updateDelivery}
                onEdit={() => setCurrentStep(2)}
              />
              
              <StepPayment
                isActive={currentStep === 3}
                data={checkoutData.payment}
                onChange={updatePayment}
                checkoutData={checkoutData}
                product={product}
              />
            </div>
            
            <div className="lg:col-span-1">
              <OrderSummary product={product} />
            </div>
          </div>
        </div>
      )}
      <CheckoutFooter />
    </div>
  );
};

export default Checkout;
